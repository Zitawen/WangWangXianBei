create definer = root@localhost view word_info as
select `wangwang`.`prelearningword`.`userId` AS `userId`,
       `wangwang`.`word`.`englishWord`       AS `englishWord`,
       `wangwang`.`word`.`pa`                AS `pa`,
       `wangwang`.`word`.`chineseWord`       AS `chineseWord`,
       `wangwang`.`word`.`englishInstance1`  AS `englishInstance1`,
       `wangwang`.`word`.`chineseInstance1`  AS `chineseInstance1`,
       `wangwang`.`word`.`englishInstance2`  AS `englishInstance2`,
       `wangwang`.`word`.`chineseInstance2`  AS `chineseInstance2`
from `wangwang`.`word`
         join `wangwang`.`prelearningword`
where ((`wangwang`.`word`.`englishWord` = `wangwang`.`prelearningword`.`englishWord`) and
       (`wangwang`.`prelearningword`.`nextDays` = 0));

