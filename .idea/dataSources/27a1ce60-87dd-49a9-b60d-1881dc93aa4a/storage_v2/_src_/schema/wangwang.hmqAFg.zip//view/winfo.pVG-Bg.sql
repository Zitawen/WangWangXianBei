create definer = root@localhost view winfo as
select `wangwang`.`prelearningword`.`userId`      AS `userId`,
       `wangwang`.`prelearningword`.`englishWord` AS `englishWord`,
       `wangwang`.`prelearningword`.`nextDays`    AS `nextDays`,
       `wangwang`.`prelearningword`.`addDays`     AS `addDays`,
       `wangwang`.`word`.`pa`                     AS `pa`,
       `wangwang`.`word`.`chineseWord`            AS `chineseWord`,
       `wangwang`.`word`.`englishInstance1`       AS `englishInstance1`,
       `wangwang`.`word`.`chineseInstance1`       AS `chineseInstance1`,
       `wangwang`.`word`.`englishInstance2`       AS `englishInstance2`,
       `wangwang`.`word`.`chineseInstance2`       AS `chineseInstance2`
from (`wangwang`.`prelearningword`
         join `wangwang`.`word`)
where (`wangwang`.`prelearningword`.`englishWord` = `wangwang`.`word`.`englishWord`);

